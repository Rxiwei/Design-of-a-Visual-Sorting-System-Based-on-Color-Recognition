import sensor
import image
import lcd
import time
import ustruct
from machine import UART    # 导入UART模块
from fpioa_manager import fm

# 初始化LCD显示
lcd.init()
sensor.reset()
sensor.set_pixformat(sensor.RGB565)  # 设置RGB565色彩格式
sensor.set_framesize(sensor.QVGA)    # 设置图像分辨率为QVGA
sensor.skip_frames(time=2000)        # 跳过前几帧以便稳定

# 初始化串口通信
fm.register(15, fm.fpioa.UART1_TX, force=True)  # 15为TX
fm.register(16, fm.fpioa.UART1_RX, force=True)  # 16为RX

uart_A = UART(UART.UART1, 115200, 8, 0, 0, timeout=1000, read_buf_len=4096)  # 串口1, 波特率115200

# 颜色阈值设置（根据需要调整）
red_threshold = (30, 100, 15, 127, 15, 127)  # 红色的HSV范围
green_threshold = (30, 100, -64, -8, -32, 32)  # 绿色的HSV范围
blue_threshold = (90, 130, -64, 64, -64, 64)  # 蓝色的HSV范围
#yellow_threshold = (20, 40, -64, 64, -64, 64)  # 黄色的HSV范围
#white_threshold = (0, 180, 0, 64, -128, 128)  # 白色的HSV范围

# 状态标记：记录是否已发送过某个颜色的字符
red_detected = False
green_detected = False
blue_detected = False
#yellow_detected = False
#white_detected = False

while True:
    img = sensor.snapshot()  # 获取图像

    # 查找红色区域
    red_blobs = img.find_blobs([red_threshold], area_threshold=200, pixels_threshold=100)
    # 查找绿色区域
    green_blobs = img.find_blobs([green_threshold], area_threshold=200, pixels_threshold=100)
    # 查找蓝色区域
    blue_blobs = img.find_blobs([blue_threshold], area_threshold=200, pixels_threshold=100)
    ## 查找黄色区域
    #yellow_blobs = img.find_blobs([yellow_threshold], area_threshold=200, pixels_threshold=100)
    ## 查找白色区域
    #white_blobs = img.find_blobs([white_threshold], area_threshold=200, pixels_threshold=100)

    # 处理红色区域
    if red_blobs:
        if not red_detected:  # 如果尚未检测到红色
            uart_A.write('r')  # 发送'r'给Arduino表示检测到红色
            print("r")
            red_detected = True  # 设置已检测到红色
        for blob in red_blobs:
            img.draw_rectangle(blob.rect(), color=(255, 0, 0))  # 红色矩形框
            img.draw_cross(blob.cx(), blob.cy(), color=(255, 0, 0))  # 红色十字
            img.draw_string(blob.x(), blob.y() - 10, "Red", color=(255, 0, 0), scale=2)  # 上方文字标注
    else:
        red_detected = False  # 红色物体离开镜头，重置状态

    # 处理绿色区域
    if green_blobs:
        if not green_detected:  # 如果尚未检测到绿色
            uart_A.write('g')  # 发送'g'给Arduino表示检测到绿色
            print("g")
            green_detected = True  # 设置已检测到绿色
        for blob in green_blobs:
            img.draw_rectangle(blob.rect(), color=(0, 255, 0))  # 绿色矩形框
            img.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0))  # 绿色十字
            img.draw_string(blob.x(), blob.y() + blob.h(), "Green", color=(0, 255, 0), scale=2)  # 下方文字标注
    else:
        green_detected = False  # 绿色物体离开镜头，重置状态

    # 处理蓝色区域
    if blue_blobs:
        if not blue_detected:  # 如果尚未检测到蓝色
            uart_A.write('b')  # 发送'b'给Arduino表示检测到蓝色
            print("b")
            blue_detected = True  # 设置已检测到蓝色
        for blob in blue_blobs:
            img.draw_rectangle(blob.rect(), color=(0, 0, 255))  # 蓝色矩形框
            img.draw_cross(blob.cx(), blob.cy(), color=(0, 0, 255))  # 蓝色十字
            img.draw_string(blob.x(), blob.y() - 10, "Blue", color=(0, 0, 255), scale=2)  # 上方文字标注
    else:
        blue_detected = False  # 蓝色物体离开镜头，重置状态

    ## 处理黄色区域
    #if yellow_blobs:
        #if not yellow_detected:  # 如果尚未检测到黄色
            #uart_A.write('y')  # 发送'y'给Arduino表示检测到黄色
            #print("y")
            #yellow_detected = True  # 设置已检测到黄色
        #for blob in yellow_blobs:
            #img.draw_rectangle(blob.rect(), color=(255, 255, 0))  # 黄色矩形框
            #img.draw_cross(blob.cx(), blob.cy(), color=(255, 255, 0))  # 黄色十字
            #img.draw_string(blob.x(), blob.y() + blob.h(), "Yellow", color=(255, 255, 0), scale=2)  # 下方文字标注
    #else:
        #yellow_detected = False  # 黄色物体离开镜头，重置状态

    ## 处理白色区域
    #if white_blobs:
        #if not white_detected:  # 如果尚未检测到白色
            #uart_A.write('w')  # 发送'w'给Arduino表示检测到白色
            #print("w")
            #white_detected = True  # 设置已检测到白色
        #for blob in white_blobs:
            #img.draw_rectangle(blob.rect(), color=(255, 255, 255))  # 白色矩形框
            #img.draw_cross(blob.cx(), blob.cy(), color=(255, 255, 255))  # 白色十字
            #img.draw_string(blob.x(), blob.y() - 10, "White", color=(255, 255, 255), scale=2)  # 上方文字标注
    #else:
        #white_detected = False  # 白色物体离开镜头，重置状态

    # 显示图像到LCD
    lcd.display(img)

    # 延时，防止串口过于频繁发送数据
    time.sleep(0.1)
